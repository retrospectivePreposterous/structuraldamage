from PIL import Image
import numpy as np
import os

for file in os.listdir():
    if file.endswith(".png") or file.endswith(".jpg") or file.endswith(".JPG"):
        im = Image.open(file)
        minimum = min(im.size)
        if minimum > 100:
            div = minimum//100
            new_size = (int(im.size[0]/div),int(im.size[1]/div))
            im = im.resize(new_size,Image.ANTIALIAS)
            im.save(file)



